package com.example.spring03_shop.members.dto;

public enum Role {
	ADMIN, USER
}
